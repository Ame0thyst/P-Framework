<header class="jumbotron jumbotron-fluid">
    <div class="container">
        <div class="row">
            <div class="col-md-12 ">
                <h1 class="h1">Portal Berita UMRI</h1>
                <h3>Gilang Wiko Wicaksono </h3>
                <h5>210401227</h5>
            </div>
        </div>
    </div>
</header>
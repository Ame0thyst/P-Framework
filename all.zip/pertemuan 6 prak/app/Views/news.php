<?= $this->extend('layout/post_layout') ?>

<?= $this->section('content') ?>

<h2 class="h2">Prodi Teknik Informatika UMRI Raih Akreditasi Unggul </h2>
<p>Semoga Prodi Teknik Informatika UMRI Raih Akreditasi Unggul DI Tahun 2028.</p>
<h2 class="h2">Mahasiswa Teknik Informatika UMRI KKN DI Malaysia</h2>
<p>30 Orang Mahasiswa Teknik Informatika UMRI KKN DI Malaysia</p>

<?= $this->endSection() ?>
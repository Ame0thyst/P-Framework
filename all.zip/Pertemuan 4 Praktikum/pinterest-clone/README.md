1. buat database dengan nama "pinterest_db"
2. ubah file env menjadi .env
3. lalu jalankan :

- php spark make:migration CreateImagesTable < engga wajib, bisa langsung skip ke bawahnya >
- php spark migrate

4. silahkan jalankan dengan

- php spark serve

"gilang wikoo"
